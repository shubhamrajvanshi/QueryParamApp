#!/bin/bash
echo 'foo'
sleep 1
exit 1