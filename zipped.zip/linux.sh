#!/bin/bash
echo 'foo'
sleep 1
touch /opt/remoteFiles/fileExecuted